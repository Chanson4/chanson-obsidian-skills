# Mistake Organisation Rules

Follow these guidelines when creating a mistake note:

1. **Preserve the original question** in full to ensure context.
2. **Record the learner’s wrong answer** or thought process to diagnose misconceptions.
3. **Provide the correct answer** clearly and unambiguously.
4. **Explain the correct solution** step by step. Do not rely on the learner to intuit the reasoning.
5. **Analyse mistakes at two levels:**
   - *Direct cause:* e.g. calculation error, misreading a condition.
   - *Deep cause:* e.g. misunderstanding of a concept, misclassification of the problem type.
6. **Link related knowledge points** so that the learner can revisit relevant notes.
7. **Identify traps or misleading conditions** in the problem statement.
8. **Suggest how to recognise similar problems** in the future.
9. **Provide review questions** for active recall on both the underlying concepts and the specific error type.
