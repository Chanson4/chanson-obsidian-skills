# Mistake Note Template

```
# Mistake: {{Topic or Key Concept}}

## Original problem
{The full question}

## My answer / reasoning
{The learner’s incorrect answer or explanation}

## Correct answer
{The correct answer}

## Solution
{Step‑by‑step solution with reasoning}

## Error analysis
### Direct cause
{What went wrong immediately}

### Deep cause
{Which concept or pattern was not understood}

## Related concepts
- Concept A
- Concept B

## Traps or misleading clues
{What the question used to mislead}

## Transfer guidance
{How to recognise and solve similar questions}

## Review questions
- Question 1
- Question 2
```
