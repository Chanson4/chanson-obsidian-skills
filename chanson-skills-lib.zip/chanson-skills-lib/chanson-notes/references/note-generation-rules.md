# Note Generation Rules

Apply these rules when distilling a learning dialogue into a study note:

1. **Preserve original questions:** The learner’s questions reveal the genuine confusion. Include them verbatim at the start of each knowledge section.
2. **Identify the underlying confusion:** Explain what the question is really about or which concept is misunderstood.
3. **State the conclusion:** Summarise the correct answer or concept in one or two sentences.
4. **Explain why:** Provide the reasoning or derivation behind the conclusion. Do not just state the result.
5. **Highlight key steps:** Use bullets or short paragraphs to emphasise critical reasoning, calculations, analogies or examples.
6. **List misconceptions:** Note any incorrect assumptions exposed in the dialogue and correct them explicitly.
7. **Connect to exam patterns:** Mention how this concept typically appears in exam questions.
8. **Generate review questions:** Conclude each section with short questions that encourage active recall.
