# Practice Question Generation Rules

These guidelines help craft effective practice questions:

1. **Originality:** Do not copy existing exam questions. Instead, design new questions inspired by exam themes.
2. **Relevance:** Base questions on the specified notes, mistakes or knowledge points. Cover definitions, mechanisms, applications and typical pitfalls.
3. **Difficulty control:** Honour the user’s requested difficulty (e.g. basic, medium, hard, exam level). Default to medium if none is specified.
4. **Number of questions:** Match the exact number requested by the user. If no number is given, generate five questions by default.
5. **Question mix:** Vary the question types (e.g. multiple choice, short answer, computation) unless the user specifies otherwise.
6. **Explanation and answer:** Provide clear answers and detailed explanations unless the user opts out.
7. **Exam style:** When requested, mirror the structure and phrasing of past exam questions, including plausible distractors and real‑world context.
8. **Review prompts:** For each set, offer summarising remarks and follow‑up questions to guide further study.
