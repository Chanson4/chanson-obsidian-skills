---
name: chanson-directory
description: Create learning vault directory structures and Markdown file templates in a user's Obsidian vault according to a specified hierarchy. Use this skill when the user asks to build folder and file layouts, such as subject folders, chapter notes, concept lists, or other study structures.
---

# Chanson Directory

## Purpose

This skill helps organise a study vault by creating folders and Markdown note placeholders. It interprets a user‑provided directory tree and builds it on disk without overwriting existing files. Each new Markdown file receives a basic title and any headings requested by the user.

## Usage

Use this skill whenever the user requests a directory or file hierarchy to be created in their Obsidian vault. It accepts a vault path, a root directory, and a tree describing folders and files. Files ending with `.md` are created as Markdown notes; other names are treated as folders. If a file or folder already exists, it is left untouched. After creation, the skill returns a report of the created and skipped items.
