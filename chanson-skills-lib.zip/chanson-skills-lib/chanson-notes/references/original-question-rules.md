# Original Question Rules

The learner’s original questions should be retained and analysed:

- **Do not discard the user’s words.** Quote the question verbatim to preserve context.
- **Analyse the question’s intent.** Summarise the concept the question touches on and note whether the user is mixing up definitions, mechanisms or applications.
- **Use the question to anchor the explanation.** Structure each note section around a specific question–answer pair.
