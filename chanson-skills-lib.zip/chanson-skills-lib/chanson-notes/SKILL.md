---
name: chanson-notes
description: Distil AI learning dialogues into structured study notes. This skill extracts the learner’s original questions, identifies the underlying confusion, preserves key reasoning steps, and generates concise but complete notes with misconceptions, exam patterns and review questions. Use this skill when the user provides an AI conversation or discussion and wants a high‑quality note for a chapter or concept.
---

# Chanson Notes

## Purpose

Chanson Notes turns chat transcripts into durable study notes. It keeps the original learner queries alongside the resolved explanation so that the learner’s cognitive journey is recorded. Each note highlights core conclusions, why they are true, the derivation or reasoning, common mistakes, typical exam questions and follow‑up questions.

## Usage

Use this skill when the user supplies an AI conversation (ChatGPT, Codex, Claude, etc.) or learning transcript and asks for a refined study note. The skill assumes the conversation belongs to a particular subject and chapter. It groups related questions, extracts the hidden conceptual gaps, summarises the explanation, and organises the material into a review‑friendly format. It outputs a Markdown draft along with metadata for the Obsidian skill to handle final formatting and insertion.
