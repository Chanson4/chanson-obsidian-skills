---
name: chanson-mistakes
description: Organise and analyse wrong answers and practice mistakes. This skill preserves the original question, the learner’s incorrect answer, provides the correct solution, and identifies both direct and deeper causes of the error. It summarises traps, links to related concepts, and generates review prompts. Use this skill when the user provides wrong problems or mistake logs.
---

# Chanson Mistakes

## Purpose

Chanson Mistakes converts raw practice errors into actionable learning material. Instead of merely listing the correct answers, it records the original question, the learner’s thought process, and a thorough error analysis. It highlights both surface mistakes and deeper knowledge gaps, suggests similar‑question recognition strategies, and proposes review questions.

## Usage

Use this skill when the user supplies a problem they answered incorrectly or a log of errors. The skill extracts the problem statement and incorrect answer, reconstructs the correct solution, and analyses what went wrong. It then produces a mistake note with categories such as direct cause, underlying cause, related knowledge, traps, transfer to similar problems, and follow‑up questions. If the user requests, the note is handed off to an Obsidian skill for formatting and insertion into a mistake notebook.
