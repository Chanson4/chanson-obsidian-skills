---
name: chanson-practice
description: Generate practice questions based on chapter notes, mistake notebooks or specified knowledge points. This skill crafts original questions that emulate exam style and difficulty, with answers and explanations. Use this skill when the user requests a set of exercises of a certain number and difficulty.
---

# Chanson Practice

## Purpose

Chanson Practice creates targeted practice sets to reinforce understanding and expose weak spots. It draws on existing notes, mistake records, or explicit knowledge points to assemble questions that reflect the style and complexity of past exams without copying them verbatim. Each question includes a brief description of what it tests, the correct answer, a full explanation, traps and common pitfalls, and hints for review.

## Usage

Use this skill when the user asks for a set of exercises linked to a particular chapter, mistake section or concept list. The skill determines the relevant knowledge points, tailors the difficulty, and generates the requested number of original questions. Answers and explanations are provided unless the user asks for questions only. The output is formatted as a draft ready to hand to an Obsidian skill for final styling and insertion.
