# Directory Creation Rules

Use these rules when building folder structures and note templates in an Obsidian vault.

- **Follow the user’s hierarchy exactly:** Create folders and files exactly as described by the user. Preserve numbering, punctuation and language.
- **Files vs. Folders:** Paths ending in `.md` are treated as Markdown notes; other names are treated as folders.
- **Create missing parents:** If a parent folder does not exist, create it automatically.
- **Do not overwrite existing files:** If a file or folder already exists, leave it intact unless the user explicitly requests overwrite.
- **Insert basic content:** When creating a new Markdown file, write a title heading (`# File name without extension`) and any section headings requested by the user.
- **Return a report:** After creation, list which folders and files were created, skipped, or caused errors.
