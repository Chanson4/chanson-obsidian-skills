# Note Content Template

Use this template when generating a study note:

```
# {{Subject}} {{Chapter}} Study Note

## Core questions addressed
- List the main questions from the dialogue.

## Knowledge points

### {{Concept 1}}
**Original question:**
> {user question}

**Problem core:** Explain the conceptual gap.

**Key conclusion:** Summarise the correct answer.

**Reasoning:** Provide the reasoning or derivation.

**Common mistakes:** List misconceptions and corrections.

**Exam patterns:** Describe how exams test this concept.

**Review questions:**
- Question 1
- Question 2

### {{Concept 2}}
...
```
