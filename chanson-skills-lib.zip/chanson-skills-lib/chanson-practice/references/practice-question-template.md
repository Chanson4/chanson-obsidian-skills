# Practice Question Template

```
# Practice Set: {{Subject}} – {{Chapter or Topic}}

## Source information
- Chapters/Concepts used:
- Mistake notes considered:
- Number of questions: {{n}}
- Difficulty: {{level}}

## Questions

### Question 1
**Type:**
**Difficulty:**
**Knowledge point:**
**Intent:**

**Question:**
{question text}

**Answer:**
{answer here}

**Explanation:**
{detailed explanation}

**Pitfalls:**
{common mistakes or traps}

### Question 2
...

## Review guidance
Summarise the focus of this practice set and suggest next steps for study.
```
