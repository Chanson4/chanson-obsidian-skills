# Collaboration with Obsidian Skills

Chanson Notes focuses on extracting and organising learning content. It does not manage Obsidian‑specific formatting such as YAML frontmatter, properties, wikilinks, tags, callouts or insertion into existing notes. When the user wants to write notes into a vault with proper formatting, Chanson Notes should hand the draft off to an Obsidian‑related skill. That skill can apply the appropriate frontmatter, tags, links and callout styles and append the note at the correct location.
